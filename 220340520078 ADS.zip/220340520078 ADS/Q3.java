class Q3{
      
      int a[]=new int[10];
	  int top1=-1;
	  int top2=a.length;
	  
	void push1(int data){
	     a[++top1]=data;
	}
	void push2(int data){
	a[--top2]=data;
	}
	
	void display(){
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
	}
  public static void main(String args[]){
     Q3 q=new Q3();
	 
	 q.push1(5);
	 q.push2(10);
	 q.push2(15);
	 q.push1(11);
	 
	 q.push2(7);
	 q.push2(40);
	 
	 
	 q.display();
  }
}