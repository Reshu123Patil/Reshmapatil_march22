class Q2{

  Node head;
  static class Node{
    int data;
	Node next;
	Node prev;
	Node(int data){
	this.data=data;
	next=null;
	prev=null;
	}
  }

  public void insertdata(int data){
     Node new_node=new Node(data);
	 Node temp=head;
	 if(head==null)
	 head=new_node;
 
  else{
	 
	new_node.next=head;
	head=new_node;
  }
  } 
  void display(){
	 Node temp=head;
     Node p=null;
    if(head==null){
      System.out.println("empty");
	}

    while(temp!=null){
		System.out.print(temp.data+"->");
		p=temp;
      temp=temp.next;
	}
	System.out.print("NULL");
	System.out.println("reverse");
	
	while(p!=null){
		System.out.print(p.data+"->");
	  
	  p=p.prev;	
	}
	
  }

   public static void main(String args[]){
      Q2 q=new Q2();
	  
	   q.insertdata(3);
	    q.insertdata(2);
		 q.insertdata(1);
	  q.display();
   }
}