public class Sorting{
          int temp;
			int j;
			int i;
       void Sorting_array(int a1[],int n){
	       
			for( i=1;i<n;i++){
			  temp=a1[i];
			   j=i-1;
			   
			   while(j>0 && a1[j]>temp){
			        a1[j+1]=a1[j];
					j=j-1;
			   }
			   a1[j+1]=temp;
			   
            //System.out.println(a1[j]);
			}
	   return;
			
			}
			
	   
	 void display(int a1[]){
		 int n=a1.length;
		 
		 for( i=0;i<n;i++){
			 System.out.println(a1[i]);
		 }
	 }

public static void main(String args[]){
     
	 Sorting s=new Sorting();
	 int a1[]={1,2,4,5,3};
	 int n=a1.length;
    s.Sorting_array(a1,n);
	 s.display(a1);
}
}